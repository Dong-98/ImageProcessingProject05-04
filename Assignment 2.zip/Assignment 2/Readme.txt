The code was produced with python 

Before starting the code, activate the python cvcourse with the command:
activate python-cvcourse

Then, go to the folder which had the project files downloaded by using:
cd (Destination)

Finally, after reaching the destination folder, type jupyter-lab and copy the link provided onto google chrome to run