The code was produced with python 

You will need the following packages in python to run the code:
- opencv
-scikit-image
-numpy
-matplotlib
-scipy

Then, go to the folder which had the project files downloaded by using:
cd (Destination)

Finally, after reaching the destination folder, type jupyter-lab and copy the link provided onto google chrome to run